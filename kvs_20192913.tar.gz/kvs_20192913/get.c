#include "kvs.h"

char* get(kvs_t* kvs, const char* key)
{
	/* do program here */
	/*
	char find[100];
	FILE *fp = fopen("student.dat","r");
	char* value = (char*)malloc(sizeof(char)*10);
	char city[100];
	while (!feof(fp)){
		fscanf(fp, "%s %s", find, city);
		if (strcmp(find, key) == 0){
			strcpy(value, city);
		}	
	}
	*/
	char* value = (char*)malloc(sizeof(char)*10);
	int a = 0;
	node_t* node = malloc(sizeof(node_t));
	node = kvs->db;
	while (1){
		a++;
		if (strcmp(key,node->key)==0){
			strcpy(value,node->value);
		}
		node = node->next;
		if (kvs->items == a){
			break;}
	}
		
	if(!value){
		printf("Failed to malloc\n");
		return NULL;
	}

	//strcpy(value, "deadbeaf");
	return value;
}
