#include "kvs.h"

int put(kvs_t* kvs, const char* key, const char* value)
{
	/* do program here */
	node_t *head = malloc(sizeof(node_t));
	head = NULL;
	node_t *tail = malloc(sizeof(node_t));
	tail = NULL;
	kvs->items = 0;

	FILE *fp = fopen("student.dat", "r");

	while (!feof(fp)){
		node_t *newNode = malloc(sizeof(node_t));
		if (fscanf(fp, "%s %s", key, value) == 2){
			strcpy(newNode->key, key);
			//printf("%s\n", newNode->key);
		
			newNode->value = value;
			//printf("%s\n", newNode->value);
			
			newNode -> next = NULL;
			if (head == NULL) {
				head = newNode;
			}
			else{
				tail->next = newNode;
			}

			tail = newNode;
			kvs->items = kvs->items + 1;
	
			printf("put: %s, %s\n", key, value);
		}
	}
	kvs -> db = head;
	fclose(fp);
	return 0;
}
