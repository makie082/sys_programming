#include "kvs.h"

int close(kvs_t* kvs)
{
	/* do program */
	node_t* node;
	node = kvs->db;
	while (node!=NULL){
		node_t *nx = node->next;
		free(node);
		node = nx;
	}
	free(kvs);
	return 0;
}
