#include "kvs.h"
#include <dlfcn.h>

int main()
{
	void* handle;
	char* error;
	kvs_t*(*open)();
	int (*close)(kvs_t* );
	int (*put)(kvs_t* , const char* , const char* );
	char*(*get)(kvs_t* ,const char*);
	handle = dlopen("./libkvs.so", RTLD_LAZY);
	if (!handle) {
		fprintf(stderr, "%s\n", dlerror());
		exit(1);
	} 
	open = (kvs_t*(*)()) dlsym(handle, "open");
	close = (int(*)(kvs_t*)) dlsym(handle, "close");
       	put = (int(*)(kvs_t*, const char*, const char*)) dlsym(handle, "put");
	get = (char*(*)(kvs_t*, const char*)) dlsym(handle, "get");	
	
	if ((error = dlerror()) != NULL) {
		fprintf(stderr, "%s\n", error);
		exit(1);
	}

	kvs_t* kvs = open();

	if(!kvs) {
		printf("Failed to open kvs\n");
		return -1;
	}

	// KVS created.  
	char key[100]; 
	char* value = (char*) malloc (sizeof(char)* 300);
	char* rvalue;

//	strcpy(key, "Eunji");
//	strcpy(value, "Seoul");

	if(put(kvs, key, value) < 0){
		printf("Failed to put data\n");
		exit(-1);
	}

	FILE *fp = fopen("student.dat","r");
	while (1){
		fscanf(fp, "%s %s", key, value);
		if(!feof(fp)){
			if(!(rvalue = get(kvs, key))){
				printf("Failed to get data\n");
				exit(-1);
			}
			printf("get: %s, %s\n", key, rvalue);
		}
		else{
			break;
		}
	}

	if (dlclose(handle) < 0) {
		fprintf(stderr, "%s\n", dlerror());
		exit(1);
	}


	return 0;
}
